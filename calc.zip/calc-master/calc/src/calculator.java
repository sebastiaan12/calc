import java.util.*;

public class calculator {

    public static void main(String[] args) {

        int num1 = 0;  // eerste getal
        int num2 = 0;  // tweede getal
        char operator;  // berekent de twee nummers
        double answer = 0.0;   //antwoord met een decimaal

        Scanner scanObject = new Scanner(System.in);

        System.out.println("+ optellen\n-  aftrekken\n  vermedigvuldigen\n/  delen\n%  modulen\n");
        System.out.println("vul hier uw nummmer in");
        num1 = scanObject.nextInt(); // scant het eerste getal
        System.out.println("Vul hier uw tweede nummer in:");
        num2 = scanObject.nextInt(); // scant het tweede getal

        System.out.println("wat wil je gaan gebruiken?");
        operator = scanObject.next().charAt(0);


        switch (operator) {
            case '+':
                answer = plus(num1, num2);
                System.out.println(answer);
                break;
            case '-':
                answer = min(num1, num2);
                System.out.println(answer);
                break;
            case '*':
                answer = vermenigvuldig(num1, num2);
                System.out.println(answer);
            case '/':
                answer = delen(num1, num2);
                System.out.println(answer);
                break;
            case '%':
                answer = modulo(num1, num2);
                System.out.println(answer);
                break;
        }
    }


    private static int plus(int num1, int num2){
        return num1 + num2;
    }

    private static int min(int num1, int num2){
        return num1 - num2;
    }

    private static int vermenigvuldig(int num1, int num2) {
        return num1 * num2;
    }

    private static int delen(int num1, int num2){
        return num1 / num2;
    }
    
    private static int modulo(int num1, int num2){
        return num1 % num2;
    }
}